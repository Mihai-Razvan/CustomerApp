package com.example.customerapp_client;

public interface HttpRequestBasics {

    void choosePath();
}
