package com.example.customerapp_client;

public interface ActivityBasics {

    ////////////////////interface used in activity class to implement methods that are common to all activity classes////////////////////////

    void getActivityElements();
    void setListeners();
}
